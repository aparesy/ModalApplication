#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H
void print_hello_string();
#endif //HELLO_WORLD_H